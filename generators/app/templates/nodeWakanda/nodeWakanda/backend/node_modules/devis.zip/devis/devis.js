'use strict';

let devis=require("./lib/core");



module.exports =devis;
